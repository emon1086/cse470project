
	<div class="footerMain">
		<div class="content">
			<div class="footer-grids">
				<div class="footer one">
					<h3>More About Company</h3>
					<p>My first Platform.</p>
					<p class="adam">- Emon, CEO</p>
					<div class="clear"></div>
				</div>
				<div class="footer two">
					<h3>Keep Connected</h3>
					<ul>
						<li><a class="fb" href="https://www.facebook.com/mohsingram/"><i></i>Like us on Facebook</a></li>
						<li><a class="fb1" href="https://www.youtube.com/mohsingram"><i></i>Subscribe on Youtube</a></li>
					</ul>
				</div>
				<div class="footer three">
					<h3>Contact Information</h3>
					<ul>
						<li>01234567890</li>
						<li><a href="mailto:info@example.com">contact@example.com</a></li>
					</ul>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>